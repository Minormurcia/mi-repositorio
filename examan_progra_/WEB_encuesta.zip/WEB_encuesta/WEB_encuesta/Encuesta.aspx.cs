﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;
using WEB_encuesta.clases;

namespace WEB_encuesta
{
    public partial class Encuesta : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            this.ddlCarroPropio.Items.Clear();
            this.ddlCarroPropio.Items.Add(new ListItem("No", "0"));
            this.ddlCarroPropio.Items.Add(new ListItem("Si", "1"));
            txtNumeroEncuesta.Text = (obtenerNumeroEncuesta() + 1).ToString();
        }

        private void Registrar(clsEncuesta encuesta)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["CONEXION"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);

            try
            {
                connection.Open();

                string query = "INSERT INTO DatosEncuesta (Nombre,Apellido,FechaNacimiento,Edad,CorreoElectronico,CarroPropio) values (@nombre,@apellido,@fechaNacimiento,@edad,@correoElectronico,@carroPropio)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@nombre", encuesta.Nombre);
                    command.Parameters.AddWithValue("@apellido", encuesta.Apellido);
                    command.Parameters.AddWithValue("@fechaNacimiento", encuesta.FechaNacimiento);
                    command.Parameters.AddWithValue("@edad", encuesta.Edad);
                    command.Parameters.AddWithValue("@correoElectronico", encuesta.CorreoElectronico);
                    command.Parameters.AddWithValue("@carroPropio", encuesta.CarroPropio);

                    int rowsAffected = command.ExecuteNonQuery();

                    string Message = "";
                    if (rowsAffected > 0)
                    {
                        Message = "Se agregó correctamente la Encuesta";
                        LimpiarCampos();
                    }
                    else
                    {
                        Message = "No se registró la Encuesta, favor validar los campos.";
                    }

                    ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + Message + "');", true);
                }
            }
            catch (Exception ex)
            {
                string errorMessage = "Error al Registrar los datos de la Encuesta. Descripción del error: " + ex.Message;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + errorMessage  + "');", true);
            }
            finally
            {
                if (connection != null && connection.State != System.Data.ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }

        private string validarCampos()
        {
            try
            {
                string Message = "";

                if (txtNombre.Text == "")
                {
                    Message = "Falta dato de Nombre.";
                }
                else if (txtNombre.Text.Length > 50)
                {
                    Message = "El Nombre no puede ser mayor a 50 caracteres.";
                }
                else if (txtApellido.Text == "")
                {
                    Message = "Falta dato de Apellido.";
                }
                else if (txtApellido.Text.Length > 100)
                {
                    Message = "El Apellido no puede ser mayor a 100 caracteres.";
                }
                else if (txtFechaNacimiento.Text == "")
                {
                    Message = "Falta dato de Fecha de Nacimiento.";
                }
                else if (txtEdad.Text == "")
                {
                    Message = "Falta dato de Edad.";
                }
                else if ((Int32.Parse(txtEdad.Text) < 18) || (Int32.Parse(txtEdad.Text) > 50))
                {
                    Message = "La Edad no puede ser menor a 18 ni mayor a 50.";
                }
                else if (txtCorreoElectronico.Text == "")
                {
                    Message = "Falta dato de Correo Electronico.";
                }
                else if (txtCorreoElectronico.Text.Length > 100)
                {
                    Message = "El Correo Electronico no puede ser mayor a 100 caracteres.";
                }

                return Message;
            }
            catch (Exception ex)
            {
                string errorMessage = "Error al Registrar los datos de la Encuesta. Descripción del error: " + ex.Message;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + errorMessage + "');", true);
                return "";
            }
        }

        private void LimpiarCampos()
        {
            txtNumeroEncuesta.Text = (obtenerNumeroEncuesta() + 1).ToString();
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtFechaNacimiento.Text = "";
            txtEdad.Text = "";
            txtCorreoElectronico.Text = "";
            ddlCarroPropio.SelectedIndex = 0;
        }

        private int obtenerNumeroEncuesta()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["CONEXION"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);

            try
            {
                int consecutivo = 0;

                connection.Open();

                string query = "SELECT TOP 1 NumeroEncuesta FROM DatosEncuesta ORDER BY NumeroEncuesta DESC";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            adapter.Fill(dt);
                            consecutivo = Int32.Parse(dt.Rows[0].ItemArray[0].ToString());
                        }
                    }
                }

                return consecutivo;
            }
            catch (Exception ex)
            {
                string errorMessage = "Error al Registrar los datos de la Encuesta. Descripción del error: " + ex.Message;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + errorMessage + "');", true);
                return 0;
            }
            finally
            {
                if (connection != null && connection.State != System.Data.ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }

        protected void btnRegistrar_Click1(object sender, EventArgs e)
        {
            try
            {
                string msg = validarCampos();
                if (msg == "")
                {
                    clsEncuesta enc = new clsEncuesta();

                    enc.Nombre = txtNombre.Text;
                    enc.Apellido = txtApellido.Text;
                    enc.FechaNacimiento = txtFechaNacimiento.Text;
                    enc.Edad = Int32.Parse(txtEdad.Text);
                    enc.CorreoElectronico = txtCorreoElectronico.Text;
                    enc.CarroPropio = ddlCarroPropio.SelectedItem.ToString();

                    Registrar(enc);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + msg + "');", true);
                }
            }
            catch (Exception ex)
            {
                string errorMessage = "Error al Registrar los datos de la Encuesta. Descripción del error: " + ex.Message;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + errorMessage + "');", true);
            }
        }
    }
}