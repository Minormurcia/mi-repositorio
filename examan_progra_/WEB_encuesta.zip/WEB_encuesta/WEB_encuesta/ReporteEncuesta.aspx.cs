﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WEB_encuesta
{
    public partial class ReporteEncuesta : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            llenarGrid();
        }

        private void llenarGrid()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["CONEXION"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);

            try
            {

                connection.Open();

                string query = "SELECT COUNT(NumeroEncuesta) as Cantidad_Encuestas,sum(case when [CarroPropio] = 'Si' then 1 else 0 end) as Si_Tiene_Vehiculo,sum(case when [CarroPropio] = 'No' then 1 else 0 end) as No_Tiene_Vehiculo FROM [ENCUESTAS].[dbo].[DatosEncuesta]";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            adapter.Fill(dt);
                            gvEncuestas.DataSource = dt;
                            gvEncuestas.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string errorMessage = "Error al Obtener el Reporte. Descripción del error: " + ex.Message;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", "alert('" + errorMessage + "');", true);
            }
            finally
            {
                if (connection != null && connection.State != System.Data.ConnectionState.Closed)
                {
                    connection.Close();
                }
            }
        }
    }
}