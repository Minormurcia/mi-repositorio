﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WEB_encuesta.clases
{
    public class clsEncuesta
    {
        public int NumeroEncuesta { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string FechaNacimiento { get; set; }
        public int Edad { get; set; }
        public string CorreoElectronico { get; set; }
        public string CarroPropio { get; set; }

    }
}